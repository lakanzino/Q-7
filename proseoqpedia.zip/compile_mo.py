#!/usr/bin/env python3
"""Compile GNU gettext MO from a simple PO file."""
from pathlib import Path
import struct

po_path = Path("/workspace/plugin/qpedia-seo-pro/languages/qpedia-seo-pro-fa_IR.po")
mo_path = Path("/workspace/plugin/qpedia-seo-pro/languages/qpedia-seo-pro-fa_IR.mo")

entries = []
msgid = None
msgstr = None
buf_id = []
buf_str = []
mode = None

def flush():
    global msgid, msgstr, buf_id, buf_str, mode
    if msgid is not None:
        mid = "".join(buf_id)
        mstr = "".join(buf_str)
        if mid != "":
            entries.append((mid, mstr))
        elif mstr:
            entries.append(("", mstr))
    msgid = None
    msgstr = None
    buf_id = []
    buf_str = []
    mode = None

for raw in po_path.read_text(encoding="utf-8").splitlines():
    line = raw.rstrip("\n")
    if line.startswith("msgid "):
        flush()
        mode = "id"
        msgid = True
        buf_id.append(line[6:].strip().strip('"').encode("utf-8").decode("unicode_escape"))
    elif line.startswith("msgstr "):
        mode = "str"
        msgstr = True
        buf_str.append(line[7:].strip().strip('"').encode("utf-8").decode("unicode_escape"))
    elif line.startswith('"') and mode:
        piece = line.strip().strip('"').encode("utf-8").decode("unicode_escape")
        if mode == "id":
            buf_id.append(piece)
        else:
            buf_str.append(piece)
flush()

# Ensure header
if not entries or entries[0][0] != "":
    entries.insert(0, ("", "Content-Type: text/plain; charset=UTF-8\n"))

entries.sort(key=lambda x: x[0].encode("utf-8"))
n = len(entries)
ids = [m.encode("utf-8") for m, _ in entries]
strs = [s.encode("utf-8") for _, s in entries]

header_size = 28
table_size = 8 * n
ids_start = header_size
str_start = header_size + 2 * table_size

id_offsets = []
off = str_start + 0
# We'll compute properly
cur = str_start + table_size * 0
# layout: header, orig table, trans table, orig strings, trans strings
orig_table = header_size
trans_table = header_size + table_size
strings_off = header_size + 2 * table_size

orig_index = []
cur = strings_off
for b in ids:
    orig_index.append((len(b), cur))
    cur += len(b) + 1
trans_index = []
for b in strs:
    trans_index.append((len(b), cur))
    cur += len(b) + 1

out = bytearray()
out += struct.pack("<Iiiiiii", 0x950412DE, 0, n, orig_table, trans_table, 0, 0)
for length, offset in orig_index:
    out += struct.pack("<II", length, offset)
for length, offset in trans_index:
    out += struct.pack("<II", length, offset)
for b in ids:
    out += b + b"\0"
for b in strs:
    out += b + b"\0"

mo_path.write_bytes(out)
print("wrote", mo_path, "entries", n, "bytes", len(out))
